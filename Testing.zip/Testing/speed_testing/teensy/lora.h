#ifndef LORA_H
#define LORA_H
#include <SPI.h>
#include <RH_RF95.h>
#define DEBUG true
#define MAX_TEST_LEN 250

class lora
{
  RH_RF95 rf95;
  int cs, interrupt, rst;
  // 250 random characters
  char randomData[MAX_TEST_LEN] = "ABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJABCDEFGHIJ";
  
  public:
  lora(int cs, int interrupt, int rst);

  void iniz();

  void sendFullMessage();

  void sendLen1(const char * msg);
};
#endif
