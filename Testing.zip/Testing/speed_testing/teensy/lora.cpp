#include "lora.h"
#define RFM95_CS 10
#define RFM95_RST 4
#define RFM95_INT 3
#define RFM95_POWER 20
#define RFM95_FREQ 915.0
lora::lora(int cs, int interrupt, int rst) : 
rf95(cs, RFM95_INT)
{
  this->cs = cs;
  this->interrupt = interrupt;
  this->rst = rst;
}

void lora::iniz()
{
  pinMode(rst, OUTPUT);
  if(DEBUG)
  {
    Serial.begin(9600);
    while(!Serial) delay(1);
  }
  if(DEBUG) Serial.println("Starting Teensy LoRa Test");
  pinMode(cs, OUTPUT);
  digitalWrite(rst, LOW);
  delay(10);
  digitalWrite(rst, HIGH);
  delay(10);
  while(!rf95.init()) {
    if(DEBUG) Serial.println("LoRa radio initialization failed");
    while(1);
  }
  if(DEBUG) Serial.println("LoRa initialization OK");
  if(!rf95.setFrequency(RFM95_FREQ)) {
    if(DEBUG) Serial.println("SetFREQ FAILED!");
    while(1);
  }
  if(DEBUG) Serial.print("Set Freq. to: ");
  if(DEBUG) Serial.println(RFM95_FREQ);

  rf95.setTxPower(RFM95_POWER, true);
  if(DEBUG) Serial.print("Set Tx power to: ");
  if(DEBUG) Serial.println(RFM95_POWER);  
}

void lora::sendFullMessage()
{
  rf95.send((uint8_t *)randomData, MAX_TEST_LEN);
  rf95.waitPacketSent();
}

void lora::sendLen1(const char * msg)
{
  rf95.send((const uint8_t *)msg, 1);
  rf95.waitPacketSent();
}
