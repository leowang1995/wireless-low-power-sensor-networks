TThis directory contains the files loaded while testing out the LoRa modules during the Nebraska July 9th-11th trip.
Very simple programs, just a constant ping from the node to the base.
The base flashes an LED when it completes a successful transaction.
Timeouts are shortened and retries are set to none.