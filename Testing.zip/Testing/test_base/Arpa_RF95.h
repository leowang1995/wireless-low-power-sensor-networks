/*
  Arpa_RF95.h - Library that implements the protocol specified
  in the ARPA-E Wireless Sensor network specification.

  Authors:
  Bryan Hatasaka
  Merek Goodrich
*/
#ifndef Arpa_RF95_h
#define Arpa_RF95_h
#include <RH_RF95.h>

#define RECV_TIMEOUT 20000
#define TRAN_TIMEOUT 300

#define DELIMINATOR ";"
#define TERMINATOR ";;"
#define HEADER "nid=%03d%s"
#define SYN "syn"
#define FIN "fin"
#define ACK "ack"
#define VAL_DELIMINATOR "="

#define HEADER_LEN 8

class Arpa_RF95
{
  public:
    Arpa_RF95(uint8_t _cs, uint8_t _interrupt, uint8_t _rst, float _freq, int8_t _power, uint8_t _en, uint8_t _nodeId, uint8_t _sendToId);
    
    /// Initializes the module with the correct settings and prepares it to receive and send 
    /// data. 
    /// Must be called before sending/reciving data for the first time. 
    /// Must be called after waking the module from sleep. 
    ///
    /// \return True if the module was initilized correctly, else false. 
    bool InitModule();

    /// Sends data through the module with no additional information or formatting. 
    /// Must call "SetSendToId()" first to set the reciving node id. 
    /// Assumes the data is NULL terminated. 
    /// MAXIMUM RH_RF95_MAX_MESSAGE_LEN characters (251 bytes). 
    ///
    /// \param[in] char* data - The null terminated character array to send over LoRa 
    /// \return bool - true if the data was successfully sent, else false 
    bool SendRawData(const char* data);

    /// Sends data through the module with no additional information or formatting. 
    /// Must call "SetSendToId()" first to set the reciving node id. 
    /// MAXIMUM RH_RF95_MAX_MESSAGE_LEN characters (251 byte). 
    /// 
    /// \param[in] char* data - the character array to send over LoRa 
    /// \param[out] uint8_t len - the number of characters to send from the array (max 251 bytes) 
    /// \return bool - true if the data was successfully sent, else false 
    bool SendRawData(const char* data, const uint8_t len);

    /// Gets data from the LoRa module and terminates it with a NULL. 
    ///
    /// \param[out] char* buf - the buffer to put the data into. The buffer must be large enough 
    ///       to hold the data (will not be longer than RH_RF95_MAX_MESSAGE_LEN (251) bytes). 
    /// \return uint8_t - the length of the return string. 
    uint8_t GetString(char* buf, uint8_t * len);


    /// Sets the id of the LoRa device that data should be sent to. 
    /// This should be called before any data is sent. 
    ///
    /// \param[in] uint8_t sendToId - the id of the LoRa module that data will be 
    ///    sent to. Ranges from 1-128 (?)
    void SetSendToId(uint8_t sendToId);

    void SetReceiveTimeout(uint16_t timeout);

    /// Get data from the LoRa module if available. 
    /// Returns the number of bytes read. This can be 0 bytes! 
    /// No timeout and no retries 
    ///
    /// \param[out] uint8_t* buf - The buffer that the data is read into 
    /// \return uint8_t - the number of bytes (octets) read 
    uint8_t GetBytes(uint8_t* buf, uint8_t * len);

    /// Block until data is available or until the timeout is reached. 
    /// The timeout is specified by the RECV_TIMEOUT macro. 
    ///
    /// \param[out] uint8_t* buf - the buffer to store the message in 
    /// \return uint8_t - the number of bytes read 
    uint8_t WaitForData(uint8_t* buf, uint8_t * len);

    /// Returns a single protocol "message". A message is specified by a header and ended by 
    /// two TERMINATOR characeters to end the message. 
    /// If a partial message is recieved, this function will block 
    /// until more bytes are read in or until the RECV_TIMEOUT has been exceeded. 
    /// The returned message will be NULL terminated. 
    ///
    /// \param[out] uint8_t * buf the buffer that the message will be stored in.
    /// \param[in/out] - the length of the buffer. If a message cannot fit into the buffer, 
    ///   then GetMessage will need to be called again to receive the rest of the message. **TODO 
    /// \return uint16_t - the number of characters read into the buffer not including the terminator.
    uint16_t GetMessage(uint8_t* buf, uint16_t len);

    /// Gets a message and reads it into buf. Will only return messages that 
    /// are addressed to the correct node and are full messages unless the buffer is full.
    ///
    /// \param[out] uint8_t* buf - The buffer that the message is read into. 
    /// \return number of bytes (octets) read. 
    ///   -1 if the receive timed out. 
    ///   -2 if the id is incorrect. 
    ///   -3 if data was received but timed out waiting for a full message. 
    ///    0 for all other errors. 
    uint16_t WaitForMessage(uint8_t* buf, uint16_t len);

    // Protocol Implementations
    
    /// Use to initiate a transaction with another node. 
    /// Must be called before sending data to another node to ensure that messages will be 
    /// read and recieved correctly by the other node. 
    ///
    /// \return bool - true if the sync was successful, else false. 
    bool Synchronize();

    /// Used to end a transaction with another node. 
    /// Must be called when data is done being sent to another node. 
    /// 
    /// \return bool - false if the close failed. 
    bool Close();

    int8_t WaitForSyn();

  private:
    /// The underlying rf95 object from the RadioHead library 
    RH_RF95 rf95;
    uint8_t cs, interrupt, rst, en, power, nodeId, sendToId;
    float freq;
    uint16_t recvTimeout;
    
    /// Builds the header according to the protocol and places it into buffer. 
    /// The header is NULL terminated. 
    /// The header will always be HEADER_LEN bytes long not including the NULL terminator. 
    ///
    /// \param[out] buffer - the buffer the header will be written to. Must be long enough. 
    /// \return bool - true if the header could successfully be written to the given buffer, else false. 
    bool BuildHeader(char* buffer) const;

    /// Parses a message in the format KEY=VALUE. Expects a NULL terminator at the end 
    /// Where the '=' is replaced with the VAL_DELIMINATOR character 
    /// *warning the VAL_DELIMINATOR must be 1 character only 
    /// *warning the params must be large enough to hold the key and value plus their 
    ///  NULL terminators.
    ///
    /// \param[out] uint8_t* key - The buffer that the key data is copied into. 
    /// \param[out] uint8_t* val - The buffer that the value data is copied into. 
    /// \return uint8_t - error code. 0 if successful. 
    ///   -1 if the string contains no VAL_DELIMINATOR. 
    uint8_t ParseParts(char* message, char* key, char* val) const;

    // These functions are used to log data to Serial. Data will only be logged if the DEBUG 
    // macro is set to true.
    void Log(const char* msg) const;
    void Logln(const char msg) const;
    void Logln(const int msg) const;
    void Logln(const float msg) const;
    void Logln(const char* msg) const;
};

#endif
