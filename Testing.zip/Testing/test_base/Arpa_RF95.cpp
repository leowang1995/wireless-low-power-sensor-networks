#include "Arpa_RF95.h"
#include <SPI.h>

#ifndef DEBUG
#define DEBUG true
#endif

Arpa_RF95::Arpa_RF95(uint8_t _cs, uint8_t _interrupt, uint8_t _rst, float _freq, int8_t _power, uint8_t _en, uint8_t _nodeId, uint8_t _sendToId) :
  rf95(_cs, _interrupt)
{
  // Set member variables
  this->cs = _cs;
  this->interrupt = _interrupt;
  this->rst = _rst;
  this->freq = _freq;
  this->power = _power;
  this->en = _en;
  this->nodeId = _nodeId;
  this->sendToId = _sendToId;
  this->recvTimeout = RECV_TIMEOUT;

  // Set pinmodes
  pinMode(rst, OUTPUT);
  pinMode(cs, OUTPUT);
  pinMode(en, OUTPUT);
  
  // Start serial if debug
  if(DEBUG)
  {
    Serial.begin(9600);
    delay(100);
  }
}


bool Arpa_RF95::InitModule()
{
  Logln("Starting Teensy LoRa");
  
  // Reset module
  Logln("Resetting module");
  digitalWrite(rst, LOW);
  delay(10);
  digitalWrite(rst, HIGH);
  delay(10);

  // Serial.println("Initializing module");
  while(!this->rf95.init()) {
    Logln("LoRa radio initialization failed");
    return false;
  }
  Logln("LoRa initialization OK");
  if(!this->rf95.setFrequency(freq)) {
    Logln("SetFREQ FAILED!");
    return false;
  }

  Log("Set Freq. to: ");
  Logln(this->freq);

  this->rf95.setTxPower(power, true);
  Log("Set Tx power to: ");
  Logln(this->power);

  this->rf95.setPromiscuous(false);
  this->rf95.setThisAddress(this->nodeId);
  this->rf95.setHeaderFrom(this->nodeId);
  SetSendToId(this->sendToId);
}

void  Arpa_RF95::SetSendToId(uint8_t _sendToId){
  this->sendToId = _sendToId;
}

void Arpa_RF95::SetReceiveTimeout(uint16_t timeout) {
  this->recvTimeout = timeout;
}

bool Arpa_RF95::SendRawData(const char* data) {
  // Assuming data is a null terminated string, send the data without the null
  return SendRawData(data, strlen(data));
}

bool Arpa_RF95::SendRawData(const char* data, const uint8_t len) {
  rf95.setHeaderTo(this->sendToId);

  if(rf95.send((uint8_t*)data, len))
    return rf95.waitPacketSent(TRAN_TIMEOUT);
  else
  {
    Logln("Arpa_RF95: ERROR: SendRawData problem; packet could not be sent");
    return false;
  }
}

uint8_t Arpa_RF95::GetString(char* buf, uint8_t * len) {
  GetBytes((uint8_t *)buf, len);
  buf[*len] = '\0';
  return *len;
}

uint8_t Arpa_RF95::GetBytes(uint8_t* buf, uint8_t * len) {
  if (this->rf95.available()) {
    if(this->rf95.recv(buf, len)) {
      return *len;
    }
  }
  return 0;
}

uint8_t Arpa_RF95::WaitForData(uint8_t* buf, uint8_t * len) {
  if(this->rf95.waitAvailableTimeout(this->recvTimeout)) {
    return GetBytes(buf, len);
  }
  else {
    return 0;
  }
}

uint16_t Arpa_RF95::GetMessage(uint8_t* buf, uint16_t len) {
  if (this->rf95.available()) {
    uint8_t max = len;
    uint8_t currentBuf[RH_RF95_MAX_MESSAGE_LEN];
    uint8_t currentLen = sizeof(currentBuf);
    uint8_t termLen = sizeof(TERMINATOR);

    len = 0;
    // Check that all data available was recieved (check last  2 char for TERMINATOR)
    while(true)
    {
      if(this->rf95.recv(currentBuf, &currentLen)) {
        Log("Arpa_RF95::GetMessage - read data from module ");
        if(currentLen + len > max - 1) // -1 to account for null we'll need to add
        {
          // Will overflow buffer
          // Todo: hold the extra bytes in a field and append next time GetMessage is called
          Logln("Arpa_RF95::GetMessage - Error - buffer can't hold full message");
          return len;
        }

        memcpy(buf + len, currentBuf, currentLen);
        len += currentLen;
        currentLen = sizeof(currentBuf);
        buf[len] = '\0'; // Add null terminator
      }

      if(len < termLen || !strcmp((char*)buf + len-termLen, TERMINATOR)) // read last chars to check for TERMINATOR
      {
        // Need to wait for more data
        if(!this->rf95.waitAvailableTimeout(RECV_TIMEOUT)) {
          Logln("Arpa_RF95::GetMessage - Error - Timeout while waiting for full message");
          return -1; // -1 for timeout
        }
      }
      else
      {
        // The message ends in TERMINATOR and doesn't overflow
        Logln("Arpa_RF95::GetMessage - Got terminator and retuning full message");
        return len;
      }
    }
  }

  Logln("Arpa_RF95::GetMessage: Error: No data available on module");
  return 0;
}

uint16_t Arpa_RF95::WaitForMessage(uint8_t* buf, uint16_t len) {
  if(this->rf95.waitAvailableTimeout(this->recvTimeout)) {
    Logln("Message available");
    return GetMessage(buf, len);
  }
  else {
    Logln("Arpa_RF95::WaitForMessage: Error: Timed out while waiting for message");
    return -1; // Timed out
  }
}

// Protocol implementations
bool Arpa_RF95::Synchronize() {
  Logln("Arpa_RF95: Synchronize() Building header, sending syn...");
  char msg[RH_RF95_MAX_MESSAGE_LEN + 1]; // +1 to account for null
  BuildHeader(msg); // no error handling
  strcat(msg, SYN);
  strcat(msg, TERMINATOR);
  SendRawData(msg);
  
  // Reuse buffer
  memset(msg, 0, RH_RF95_MAX_MESSAGE_LEN);

  Logln("Arpa_RF95: Synchronize() waiting for ack...");
  // Wait for ack
  uint8_t len = WaitForMessage((uint8_t *)msg, RH_RF95_MAX_MESSAGE_LEN + 1);

  // Synchronize timed out or wrong id or not the right message
  if(len <= 0)
  {
    Logln("Arpa_RF95: Synchronize() WaitForMessage failed");
    return false;
  }

  Logln("Arpa_RF95: Synchronize() got message:");
  Logln(msg);

  // Parse message, look for sync message - assuming correct id so skip that part
  char *ptr = strtok(msg +  HEADER_LEN, DELIMINATOR);

  if(ptr != NULL) {
    // Parse through recieved data and verify is an ack
    char key[128];
    char val[128];

    int error = ParseParts(ptr, key, val);

    if(!error && strcmp(ACK, key) == 0 && strcmp(SYN, val) == 0)
      return true;
  }

  return false;
}

bool Arpa_RF95::Close() {
  Logln("Arpa_RF95: Close() Building header, sending fin...");
  char msg[RH_RF95_MAX_MESSAGE_LEN + 1]; // +1 to account for null
  BuildHeader(msg); // no error handling
  strcat(msg, FIN);
  strcat(msg, TERMINATOR);
  SendRawData(msg);
  
  // Reuse buffer
  memset(msg, 0, RH_RF95_MAX_MESSAGE_LEN);

  Logln("Arpa_RF95: Close() waiting for ack...");
  // Wait for ack
  uint8_t len = WaitForMessage((uint8_t *)msg, RH_RF95_MAX_MESSAGE_LEN + 1);

  // Close timed out or wrong id or not the right message
  if(len <= 0)
  {
    Logln("Arpa_RF95: Close() WaitForMessage failed");
    return false;
  }
  
  // Parse message, look for close message - assuming correct id so skip that part
  char *ptr = strtok(msg +  HEADER_LEN, DELIMINATOR);

  Logln("Arpa_RF95: Close() got message:");
  Logln(msg);
  if(ptr != NULL) {
    // Parse through recieved data and verify is an ack
    char key[128];
    char val[128];

    int error = ParseParts(ptr, key, val);
    
    if(!error && strcmp(ACK, key) == 0 && strcmp(FIN, val) == 0)
      return true;
  }

  return false;
}

int8_t Arpa_RF95::WaitForSyn() {
  Logln("Arpa_RF95: WaitForSyn() waiting for ack...");
  char msg[RH_RF95_MAX_MESSAGE_LEN + 1]; // +1 to account for null
  // Wait for ack
  uint8_t len = WaitForMessage((uint8_t *)msg, RH_RF95_MAX_MESSAGE_LEN + 1);
  
  // Wait timed out or wrong id or not the right message
  if(len <= 0)
  {
    Logln("Arpa_RF95: WaitForSyn() WaitForSyn timed out or failed");
    return len;
  }
  
  // Parse message, look for syn message - assuming correct id so skip that part
  char *ptr = strtok(msg +  HEADER_LEN, DELIMINATOR);

  Logln("Arpa_RF95: WaitForSyn() got message:");
  Logln(msg);
  Logln("Message from: ");
  Logln(rf95.headerFrom());
  
  if(ptr != NULL) {
    if(strcmp(SYN, ptr) == 0) {
      Logln("Arpa_RF95: WaitForSyn() Got syn, sending back ack");
      this->SetSendToId(rf95.headerFrom());
      // We got a syn, send back an ack
      memset(msg, 0, RH_RF95_MAX_MESSAGE_LEN);
      BuildHeader(msg); // no error handling
      strcat(msg, ACK);
      strcat(msg, VAL_DELIMINATOR);
      strcat(msg, SYN);
      strcat(msg, TERMINATOR);
      SendRawData(msg);
      return 1;
    }
    else
    {
      // Failed
      return -4;
    }
    
  }

  return -4;
}


bool Arpa_RF95::BuildHeader(char* buffer) const {
  int written = snprintf(buffer, HEADER_LEN + 1, HEADER, this->nodeId, DELIMINATOR);
  if (written == HEADER_LEN)
    return true;
  else if (written < 0) {
    Logln("Arpa_RF95: ERROR: BuildHeader(char* buffer) const: encoding error with snprintf");
    return false;
  }
  else {
    Logln("Arpa_RF95: ERROR: BuildHeader(char* buffer) const: Not all header characters could be written");
    return false;
  }
}

uint8_t Arpa_RF95::ParseParts(char* message, char* key, char* val) const {
  uint16_t delimPos = 0;
  while(message[delimPos] != VAL_DELIMINATOR[0])
  {
    // If we run into a NULL instead of deliminator then retun -1
    if(message[delimPos] == '\0')
      return -1;
    ++delimPos;
  }

  strncpy(key, message, delimPos);
  key[delimPos] = '\0'; // Null terminate the key
  strcpy(val, message + delimPos + strlen(VAL_DELIMINATOR));
  // assuming message is null terminated, so the null will be copied to val
  return 0;
}


// Logging
void Arpa_RF95::Log(const char* msg) const {
  if(DEBUG) Serial.print(msg);
}

void Arpa_RF95::Logln(char msg) const {
  if(DEBUG) Serial.println(msg);
}

void Arpa_RF95::Logln(int msg) const {
  if(DEBUG) Serial.println(msg);
}

void Arpa_RF95::Logln(float msg) const {
  if(DEBUG) Serial.println(msg);
}

void Arpa_RF95::Logln(const char* msg) const {
  if(DEBUG) Serial.println(msg);
}
